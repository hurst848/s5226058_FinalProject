THIS DOCUMENT SPECIFIES HOW TO USE THE APPLICATIONS PROVIDED


=== BUILD INSTRUCTIONS ===

To play the demo, go in th s5226058_Build folder,
and select the s5226058_ExcecutableDemo.exe file. 
A predefined and pre-seeded procedural planet will 
then be generated.

Controls:

Pitch and yax: mouse
Forward: 	W
Left: 		A
Back: 		S
Right: 		D
Up:		Space
Down: 		L Control


=== Package instructions ===

To use the package, follow these instructions

1. Create a new unity project using the universal render pipeline
2. Import a this package
3. Create the render feature that the console specifies
4. Assign a game object the Hurst_planetgenerator script
5. Assign the camera the cameraScript script
