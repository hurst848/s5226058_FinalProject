using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class test : MonoBehaviour
{

    public List<Biome> biomes;

    int BiomeMapResolution = 50;

    List<float> temperatureData;
    int[] biomeMap;
    


    private void Start()
    {
        
    }
}
